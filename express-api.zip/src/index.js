var express = require('express');
var app = express();
console.log('AAPPPPP', app);
app.listen(8080, function () {
    console.log('HERE IN SERVER_ HELLO!');
});
